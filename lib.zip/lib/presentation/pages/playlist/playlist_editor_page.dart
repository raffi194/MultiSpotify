import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:collection/collection.dart';

import '../../../core/di/providers.dart';

class PlaylistEditorPage extends ConsumerStatefulWidget {
  final String playlistId;

  const PlaylistEditorPage({
    super.key,
    required this.playlistId,
  });

  @override
  ConsumerState<PlaylistEditorPage> createState() =>
      _PlaylistEditorPageState();
}

class _PlaylistEditorPageState extends ConsumerState<PlaylistEditorPage> {
  final name = TextEditingController();
  final description = TextEditingController();

  bool loading = false;
  bool initialized = false;

  String? originalName;
  String? originalDescription;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (!initialized) {
      final playlists = ref.read(playlistControllerProvider).value;

      final target = playlists?.firstWhereOrNull(
        (p) => p.id == widget.playlistId,
      );

      if (target != null) {
        originalName = target.name;
        originalDescription = target.description ?? "";

        name.text = originalName!;
        description.text = originalDescription!;
      }

      initialized = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authControllerProvider);

    return Scaffold(
      appBar: AppBar(
        // sesuai permintaan Anda → selalu "Edit Playlist"
        title: const Text("Edit Playlist"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(hintText: "Nama Playlist"),
            ),
            const SizedBox(height: 12),

            TextField(
              controller: description,
              decoration: const InputDecoration(hintText: "Deskripsi Playlist"),
            ),
            const SizedBox(height: 24),

            loading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: () => _onSave(user),
                    child: const Text("Simpan Perubahan"),
                  ),
          ],
        ),
      ),
    );
  }

  // ================================================================
  // LOGIKA EDIT PLAYLIST (FINAL)
  // ================================================================
  Future<void> _onSave(user) async {
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Anda belum login.")),
      );
      return;
    }

    final newName = name.text.trim();
    final newDesc = description.text.trim();

    // VALIDASI NAMA WAJIB
    if (newName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Nama playlist belum diisi")),
      );
      return;
    }

    // CEK PERUBAHAN
    final changedName = newName != originalName;
    final changedDesc = newDesc != originalDescription;

    // Jika tidak ada perubahan, tidak memanggil update
    if (!changedName && !changedDesc) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Tidak ada perubahan.")),
      );
      return;
    }

    // Mulai loading
    setState(() => loading = true);

    // UPDATE PLAYLIST (sesuai logika Anda)
    await ref.read(playlistControllerProvider.notifier).updatePlaylist(
          widget.playlistId,
          newName,
          newDesc,
          user.id,
        );

    // Notifikasi sukses
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Playlist berhasil diperbarui")),
    );

    setState(() => loading = false);

    Navigator.pop(context);
  }
}
