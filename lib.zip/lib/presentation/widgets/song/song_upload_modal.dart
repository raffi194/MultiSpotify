import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../domain/entities/song_entity.dart';
import '../../../infrastructure/supabase/supabase_upload_service.dart';

class SongUploadModal extends ConsumerStatefulWidget {
  const SongUploadModal({super.key});

  @override
  ConsumerState<SongUploadModal> createState() => _SongUploadModalState();
}

class _SongUploadModalState extends ConsumerState<SongUploadModal>
    with SingleTickerProviderStateMixin {
  final title = TextEditingController();
  final artist = TextEditingController();

  File? cover;
  File? audio;
  bool uploading = false;

  late AnimationController _anim;
  late Animation<double> _slide;

  @override
  void initState() {
    super.initState();

    _anim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    _slide = Tween<double>(begin: 160, end: 0).animate(
      CurvedAnimation(parent: _anim, curve: Curves.easeOutCubic),
    );

    _anim.forward();
  }

  // ============================================================
  // PICK COVER
  // ============================================================
  Future pickCover() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    if (res != null) {
      setState(() => cover = File(res.files.single.path!));
    }
  }

  // ============================================================
  // PICK AUDIO
  // ============================================================
  Future pickAudio() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res != null) {
      setState(() => audio = File(res.files.single.path!));
    }
  }

  // ============================================================
  // UPLOAD PROCESS
  // ============================================================
  Future upload() async {
    if (title.text.trim().isEmpty) {
      return notify("Judul lagu wajib diisi");
    }
    if (artist.text.trim().isEmpty) {
      return notify("Nama artis wajib diisi");
    }
    if (cover == null) {
      return notify("Cover belum dipilih");
    }
    if (audio == null) {
      return notify("File audio belum dipilih");
    }

    final user = ref.read(authControllerProvider);
    if (user == null) return;

    setState(() => uploading = true);

    try {
      final uploader = SupabaseUploadService();

      final coverUrl = await uploader.uploadImage(cover!);
      final audioUrl = await uploader.uploadAudio(audio!);

      final song = SongEntity(
        id: "",
        title: title.text.trim(),
        artist: artist.text.trim(),
        coverUrl: coverUrl,
        audioUrl: audioUrl,
        uploaderId: user.id,
      );

      await ref.read(songsControllerProvider.notifier).uploadSong(song);

      notify("Lagu berhasil diupload!");
      Navigator.pop(context);
    } catch (e) {
      notify("Gagal upload: $e");
    }

    setState(() => uploading = false);
  }

  void notify(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Scaffold(
        backgroundColor: Colors.black.withOpacity(0.55),
        body: Stack(
          children: [
            // Background blur
            BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
              child: Container(color: Colors.black.withOpacity(0.25)),
            ),

            AnimatedBuilder(
              animation: _anim,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _slide.value),
                  child: child,
                );
              },
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: size.width,
                  height: size.height * 0.88,
                  padding: const EdgeInsets.all(22),
                  decoration: const BoxDecoration(
                    color: Color(0xFF131313),
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(26),
                    ),
                  ),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 50,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(50),
                          ),
                        ),
                      ),

                      const SizedBox(height: 28),
                      const Text(
                        "Upload Lagu Baru",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // =====================================================
                      // INPUT TITLE
                      // =====================================================
                      _inputField(
                        controller: title,
                        label: "Judul Lagu",
                      ),

                      const SizedBox(height: 14),

                      // =====================================================
                      // INPUT ARTIST
                      // =====================================================
                      _inputField(
                        controller: artist,
                        label: "Artist",
                      ),

                      const SizedBox(height: 24),

                      // =====================================================
                      // COVER PICKER + PREVIEW
                      // =====================================================
                      InkWell(
                        onTap: pickCover,
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: _box(),
                          child: Row(
                            children: [
                              const Icon(Icons.image, color: Colors.white70),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Text(
                                  cover == null
                                      ? "Pilih Cover"
                                      : cover!.path.split('/').last,
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                              if (cover != null)
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: Image.file(
                                    cover!,
                                    width: 46,
                                    height: 46,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 14),

                      // =====================================================
                      // AUDIO PICKER + PREVIEW
                      // =====================================================
                      InkWell(
                        onTap: pickAudio,
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: _box(),
                          child: Row(
                            children: [
                              const Icon(Icons.music_note,
                                  color: Colors.white70),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Text(
                                  audio == null
                                      ? "Pilih File Audio"
                                      : audio!.path.split('/').last,
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                              if (audio != null)
                                const Icon(Icons.check_circle,
                                    color: Colors.greenAccent),
                            ],
                          ),
                        ),
                      ),

                      const Spacer(),

                      // =====================================================
                      // BUTTON UPLOAD
                      // =====================================================
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: uploading ? null : upload,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.greenAccent.shade700,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: uploading
                              ? const SizedBox(
                                  height: 22,
                                  width: 22,
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Text(
                                  "Upload Lagu",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                        ),
                      ),

                      const SizedBox(height: 12),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  // ===================================================================
  // HELPER UI
  // ===================================================================
  Widget _inputField({
    required TextEditingController controller,
    required String label,
  }) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        filled: true,
        fillColor: Colors.white10,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  BoxDecoration _box() {
    return BoxDecoration(
      color: Colors.white10,
      borderRadius: BorderRadius.circular(12),
    );
  }
}
