class SupabaseKeys {
  static const projectUrl = "https://uyvlceukrgtycycupvvy.supabase.co";
  static const anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV5dmxjZXVrcmd0eWN5Y3VwdnZ5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM5MDgzNDQsImV4cCI6MjA3OTQ4NDM0NH0.cIqC74hB_eQ6KGuM0alHp4qxz2yoNEr3xK0ClY4Gk58";
}
